package com.tkor.widget;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(7, 11, 17);
    private static final int PANEL = Color.rgb(14, 20, 30);
    private static final int CARD = Color.rgb(20, 28, 40);
    private static final int LINE = Color.rgb(48, 58, 72);
    private static final int TEXT = Color.rgb(245, 246, 248);
    private static final int MUTED = Color.rgb(174, 183, 196);
    private static final int GOLD = Color.rgb(237, 196, 94);
    private static final int GOLD_BG = Color.rgb(47, 38, 21);
    private static final String FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLSfgIZeRQK0quuHZNal2X4hUEjP-xjF03C3t0YV1K1dmmWKpaQ/viewform?usp=publish-editor";

    private LinearLayout content;
    private Button tabSchedule, tabGuild, tabNotice;
    private TextView boardText;
    private int selectedTab = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        setContentView(buildRoot());
        showSchedule();
        refreshRemoteData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        renderSelectedTab();
        refreshRemoteData();
    }

    private View buildRoot() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        // Base breathing room. System-bar insets are added below so the header never
        // sits under the status bar and the scroll area stays above navigation controls.
        root.setPadding(dp(16), dp(24), dp(16), dp(20));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int topInset;
            int bottomInset;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets topBars = insets.getInsets(
                        WindowInsets.Type.statusBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets navBars = insets.getInsets(WindowInsets.Type.navigationBars());
                topInset = topBars.top;
                bottomInset = navBars.bottom;
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(dp(16), topInset + dp(24), dp(16), bottomInset + dp(20));
            return insets;
        });

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView logo = text("TKOR", 32, GOLD, true);
        TextView subtitle = text("GUILD SCHEDULE", 11, MUTED, true);
        subtitle.setLetterSpacing(.18f);
        titleBox.addView(logo);
        titleBox.addView(subtitle);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView date = text(WidgetData.dateLabel(), 15, TEXT, true);
        date.setGravity(Gravity.END);
        header.addView(date);
        root.addView(header);

        boardText = text(NativeAppData.cachedNotice(this), 13, TEXT, true);
        boardText.setPadding(dp(12), dp(10), dp(12), dp(10));
        boardText.setSingleLine(false);
        boardText.setBackground(cardBackground(Color.rgb(24, 34, 52), Color.rgb(87, 105, 137), 14));
        LinearLayout.LayoutParams boardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        boardLp.topMargin = dp(12);
        root.addView(boardText, boardLp);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(0, dp(12), 0, dp(12));
        tabSchedule = tabButton("일정", 0);
        tabGuild = tabButton("길드전", 1);
        tabNotice = tabButton("공지", 2);
        tabs.addView(tabSchedule, weightLp());
        tabs.addView(tabGuild, weightLp());
        tabs.addView(tabNotice, weightLp());
        root.addView(tabs);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(32), 0, dp(180));
        scroll.addView(content, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private Button tabButton(String label, int index) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setMinHeight(dp(46));
        b.setPadding(dp(6), 0, dp(6), 0);
        b.setOnClickListener(v -> {
            selectedTab = index;
            renderSelectedTab();
        });
        return b;
    }

    private void styleTabs() {
        Button[] tabs = {tabSchedule, tabGuild, tabNotice};
        for (int i = 0; i < tabs.length; i++) {
            boolean on = i == selectedTab;
            tabs[i].setTextColor(on ? GOLD : MUTED);
            tabs[i].setBackground(cardBackground(on ? GOLD_BG : PANEL, on ? GOLD : LINE, 10));
        }
    }

    private void renderSelectedTab() {
        if (content == null) return;
        if (selectedTab == 0) showSchedule();
        else if (selectedTab == 1) showGuild();
        else showNotice();
    }

    private void showSchedule() {
        selectedTab = 0;
        styleTabs();
        content.removeAllViews();

        addSectionTitle("오늘의 숙제", "매일 11:00 초기화", () -> {
            NativeAppData.resetHomework(this);
            showSchedule();
        });

        List<NativeAppData.HomeworkItem> items = NativeAppData.homeworkItems();
        Set<String> done = NativeAppData.homeworkDone(this);
        int complete = 0;
        for (NativeAppData.HomeworkItem item : items) if (done.contains(item.id)) complete++;
        TextView score = text(complete + "/7 완료", 13, GOLD, true);
        score.setPadding(dp(2), 0, 0, dp(8));
        content.addView(score);

        for (NativeAppData.HomeworkItem item : items) {
            content.addView(checkRow(item.title, item.sub, done.contains(item.id), checked -> {
                NativeAppData.setHomeworkDone(this, item.id, checked);
                showSchedule();
            }), rowLp());
        }

        addSpacer(16);
        addSectionTitle("오늘 일정", "체크하면 완료 처리", () -> {
            WidgetData.resetToday(this);
            TkorWidgetProvider.requestRefresh(this);
            showSchedule();
        });

        List<EventItem> events = WidgetData.todayEvents(this);
        if (events.isEmpty()) {
            TextView empty = text("남은 일정이 없습니다.", 14, MUTED, false);
            empty.setPadding(dp(14), dp(18), dp(14), dp(18));
            empty.setBackground(cardBackground(PANEL, LINE, 12));
            content.addView(empty);
        } else {
            for (EventItem event : events) {
                content.addView(eventRow(event), rowLp());
            }
        }
    }

    private void showGuild() {
        selectedTab = 1;
        styleTabs();
        content.removeAllViews();

        addSectionTitle(WidgetData.guildDayLabel(), "게임 기준 11:00 변경", () -> {
            WidgetData.resetGuildToday(this);
            TkorWidgetProvider.requestRefresh(this);
            showGuild();
        });

        if (WidgetData.isSaturdayGameDay()) {
            content.addView(shieldPanel(), rowLp());
        }

        List<GuildTask> tasks = WidgetData.guildTasksForGameDay();
        if (tasks.isEmpty()) {
            TextView none = text("오늘은 길드전 체크 항목이 없습니다.", 14, MUTED, false);
            none.setPadding(dp(14), dp(18), dp(14), dp(18));
            none.setBackground(cardBackground(PANEL, LINE, 12));
            content.addView(none);
        } else {
            for (GuildTask task : tasks) {
                boolean checked = WidgetData.isGuildDone(this, task.id);
                content.addView(checkRow(task.name, "", checked, value -> {
                    WidgetData.toggleGuildDone(this, task.id);
                    NativeAppData.syncGuildToHomework(this, task.id);
                    TkorWidgetProvider.requestRefresh(this);
                    showGuild();
                }), rowLp());
            }
        }

        TextView note = text(WidgetData.guildNoteForGameDay(), 13, MUTED, false);
        note.setPadding(dp(13), dp(12), dp(13), dp(12));
        note.setBackground(cardBackground(PANEL, LINE, 12));
        LinearLayout.LayoutParams noteLp = rowLp(); noteLp.topMargin = dp(6);
        content.addView(note, noteLp);

        addSpacer(18);
        addSectionTitle("서바이벌 배틀", "노란색은 길드전과 겹치는 시간", null);
        List<SurvivalItem> survival = WidgetData.survivalForGameDay();
        for (SurvivalItem item : survival) content.addView(survivalRow(item), rowLp());
    }

    private void showNotice() {
        selectedTab = 2;
        styleTabs();
        content.removeAllViews();

        addSectionTitle("공지사항", "시트에 입력한 내용이 여기 표시됩니다", null);
        List<String> notices = NativeAppData.cachedNoticeItems(this);
        if (notices.isEmpty()) {
            TextView empty = text("등록된 공지사항이 없습니다.", 14, MUTED, false);
            empty.setPadding(dp(14), dp(18), dp(14), dp(18));
            empty.setBackground(cardBackground(PANEL, LINE, 12));
            content.addView(empty, rowLp());
        } else {
            for (String item : notices) {
                TextView row = text(item, 15, TEXT, true);
                row.setPadding(dp(14), dp(16), dp(14), dp(16));
                row.setBackground(cardBackground(CARD, LINE, 12));
                content.addView(row, rowLp());
            }
        }

        addSpacer(10);
        TextView title = text("건의 · 축하 제보", 20, TEXT, true);
        content.addView(title);
        TextView desc = text("제보 내용은 기존 TKOR 제보 폼으로 연결됩니다.", 13, MUTED, false);
        desc.setPadding(0, dp(6), 0, dp(12));
        content.addView(desc);
        Button report = actionButton("제보하기");
        report.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(FORM_URL))));
        content.addView(report, rowLp());

        addSpacer(14);
        TextView appInfo = text("TKOR 길드 일정\n위젯과 앱이 같은 일정·체크 데이터를 사용합니다.", 13, MUTED, false);
        appInfo.setPadding(dp(14), dp(14), dp(14), dp(14));
        appInfo.setBackground(cardBackground(PANEL, LINE, 12));
        content.addView(appInfo, rowLp());
    }

    private View eventRow(EventItem event) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(12), dp(10), dp(12));
        row.setBackground(cardBackground(CARD, LINE, 12));

        TextView time = text(event.time, 21, GOLD, true);
        time.setGravity(Gravity.CENTER);
        row.addView(time, new LinearLayout.LayoutParams(dp(76), ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView name = text(event.name, 17, TEXT, true);
        name.setPadding(dp(10), 0, dp(8), 0);
        row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button done = smallButton("완료");
        done.setOnClickListener(v -> {
            WidgetData.markDone(this, event.completionKey());
            TkorWidgetProvider.requestRefresh(this);
            showSchedule();
        });
        row.addView(done);
        return row;
    }

    private View survivalRow(SurvivalItem item) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(13), dp(14), dp(13));
        row.setBackground(cardBackground(item.highlighted ? GOLD_BG : CARD, item.highlighted ? GOLD : LINE, 12));
        TextView time = text(item.time, 15, item.highlighted ? GOLD : TEXT, true);
        row.addView(time, new LinearLayout.LayoutParams(dp(128), ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView name = text(item.name, 16, TEXT, true);
        row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    private View shieldPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(cardBackground(CARD, GOLD, 12));
        TextView title = text("보호막 타이머", 16, GOLD, true);
        box.addView(title);

        long end = WidgetData.shieldEndMillis(this);
        String status = end > System.currentTimeMillis() ? "보호막 진행 중" : "8시간 또는 12시간을 선택하세요.";
        TextView sub = text(status, 13, MUTED, false);
        sub.setPadding(0, dp(4), 0, dp(8));
        box.addView(sub);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button b8 = smallButton("8시간");
        Button b12 = smallButton("12시간");
        Button start = smallButton("시작");
        b8.setOnClickListener(v -> { WidgetData.setShieldHours(this, 8); showGuild(); });
        b12.setOnClickListener(v -> { WidgetData.setShieldHours(this, 12); showGuild(); });
        start.setOnClickListener(v -> { WidgetData.startShield(this); TkorWidgetProvider.requestRefresh(this); showGuild(); });
        actions.addView(b8, weightLp()); actions.addView(b12, weightLp()); actions.addView(start, weightLp());
        box.addView(actions);
        return box;
    }

    private interface CheckedListener { void onChanged(boolean checked); }

    private View checkRow(String title, String sub, boolean checked, CheckedListener listener) {
        CheckBox cb = new CheckBox(this);
        cb.setText(title + (sub == null || sub.isEmpty() ? "" : "\n" + sub));
        cb.setTextColor(checked ? MUTED : TEXT);
        cb.setTextSize(15);
        cb.setTypeface(Typeface.DEFAULT_BOLD);
        cb.setButtonTintList(new android.content.res.ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{GOLD, MUTED}));
        cb.setPadding(dp(10), dp(7), dp(10), dp(7));
        cb.setMinHeight(dp(54));
        cb.setChecked(checked);
        cb.setBackground(cardBackground(CARD, LINE, 12));
        cb.setOnCheckedChangeListener((buttonView, isChecked) -> listener.onChanged(isChecked));
        return cb;
    }

    private void addSectionTitle(String title, String sub, Runnable reset) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(13));
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(title, 21, TEXT, true));
        if (sub != null && !sub.isEmpty()) left.addView(text(sub, 12, MUTED, false));
        row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (reset != null) {
            Button b = smallButton("초기화");
            b.setOnClickListener(v -> reset.run());
            row.addView(b);
        }
        content.addView(row);
    }

    private void refreshRemoteData() {
        WidgetData.refreshExtrasAsync(this, () -> runOnUiThread(() -> {
            if (selectedTab == 0) showSchedule();
            TkorWidgetProvider.requestRefresh(this);
        }));
        NativeAppData.refreshNoticeAsync(this, value -> runOnUiThread(() -> {
            if (boardText != null) boardText.setText(value);
            if (selectedTab == 2) showNotice();
        }));
        NativeAppData.refreshNoticeItemsAsync(this, value -> runOnUiThread(() -> {
            if (selectedTab == 2) showNotice();
        }));
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setLineSpacing(0f, 1.08f);
        return v;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(TEXT);
        b.setMinWidth(0); b.setMinimumWidth(0);
        b.setMinHeight(dp(38)); b.setMinimumHeight(dp(38));
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setBackground(cardBackground(PANEL, LINE, 9));
        return b;
    }

    private Button actionButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.rgb(18, 20, 24));
        b.setBackground(cardBackground(GOLD, GOLD, 11));
        b.setMinHeight(dp(48));
        return b;
    }

    private GradientDrawable cardBackground(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private LinearLayout.LayoutParams rowLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(10);
        return p;
    }

    private LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.leftMargin = dp(3); p.rightMargin = dp(3);
        return p;
    }

    private void addSpacer(int h) {
        View v = new View(this);
        content.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }

    private int dp(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }
}
