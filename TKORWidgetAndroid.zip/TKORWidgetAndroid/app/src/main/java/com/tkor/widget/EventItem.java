package com.tkor.widget;

final class EventItem {
    final String time;
    final String name;

    EventItem(String time, String name) {
        this.time = time;
        this.name = name;
    }

    String completionKey() {
        if ("치즈".equals(name)) return "group:치즈";
        if ("수정골짜기".equals(name)) return "group:수정골짜기";
        return "single:" + time + "|" + name;
    }
}
