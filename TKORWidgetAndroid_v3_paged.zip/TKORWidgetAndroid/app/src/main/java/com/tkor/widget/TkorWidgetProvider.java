package com.tkor.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import java.util.List;

public class TkorWidgetProvider extends AppWidgetProvider {
    private static final String ACTION_COMPLETE = "com.tkor.widget.COMPLETE";
    private static final String ACTION_RESET = "com.tkor.widget.RESET";
    private static final String ACTION_REFRESH = "com.tkor.widget.REFRESH";
    private static final String ACTION_SHOW_TODAY = "com.tkor.widget.SHOW_TODAY";
    private static final String ACTION_SHOW_SURVIVAL = "com.tkor.widget.SHOW_SURVIVAL";
    private static final String EXTRA_KEY = "completion_key";
    private static final int DETAIL_HEIGHT_DP = 430;

    private static final int[] ROW_IDS = {R.id.row1,R.id.row2,R.id.row3,R.id.row4,R.id.row5,R.id.row6,R.id.row7};
    private static final int[] TIME_IDS = {R.id.time1,R.id.time2,R.id.time3,R.id.time4,R.id.time5,R.id.time6,R.id.time7};
    private static final int[] NAME_IDS = {R.id.name1,R.id.name2,R.id.name3,R.id.name4,R.id.name5,R.id.name6,R.id.name7};
    private static final int[] CHECK_IDS = {R.id.check1,R.id.check2,R.id.check3,R.id.check4,R.id.check5,R.id.check6,R.id.check7};

    private static final int[] SURV_ROW_IDS = {R.id.survRow1,R.id.survRow2,R.id.survRow3,R.id.survRow4,R.id.survRow5,R.id.survRow6};
    private static final int[] SURV_TIME_IDS = {R.id.survTime1,R.id.survTime2,R.id.survTime3,R.id.survTime4,R.id.survTime5,R.id.survTime6};
    private static final int[] SURV_NAME_IDS = {R.id.survName1,R.id.survName2,R.id.survName3,R.id.survName4,R.id.survName5,R.id.survName6};

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateOne(context, manager, id);
        WidgetData.refreshExtrasAsync(context, () -> updateAll(context));
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int appWidgetId, Bundle newOptions) {
        updateOne(context, manager, appWidgetId);
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        for (int id : appWidgetIds) WidgetData.clearPageState(context, id);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        int widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (ACTION_COMPLETE.equals(action)) {
            String key = intent.getStringExtra(EXTRA_KEY);
            if (key != null) WidgetData.markDone(context, key);
            updateAll(context);
            return;
        }
        if (ACTION_RESET.equals(action)) {
            WidgetData.resetToday(context);
            updateAll(context);
            return;
        }
        if (ACTION_SHOW_TODAY.equals(action) && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            WidgetData.setCompactPage(context, widgetId, 0);
            updateOne(context, AppWidgetManager.getInstance(context), widgetId);
            return;
        }
        if (ACTION_SHOW_SURVIVAL.equals(action) && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            WidgetData.setCompactPage(context, widgetId, 1);
            updateOne(context, AppWidgetManager.getInstance(context), widgetId);
            return;
        }
        if (ACTION_REFRESH.equals(action)) {
            final PendingResult result = goAsync();
            WidgetData.refreshExtrasAsync(context, () -> {
                updateAll(context);
                result.finish();
            });
            return;
        }
        super.onReceive(context, intent);
    }

    private static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, TkorWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    private static boolean isDetail(AppWidgetManager manager, int id) {
        Bundle options = manager.getAppWidgetOptions(id);
        int h = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
        return h >= DETAIL_HEIGHT_DP;
    }

    private static void bindTodayRows(Context context, RemoteViews rv) {
        List<EventItem> events = WidgetData.todayEvents(context);
        for (int i = 0; i < ROW_IDS.length; i++) {
            if (i < events.size()) {
                EventItem e = events.get(i);
                rv.setViewVisibility(ROW_IDS[i], View.VISIBLE);
                rv.setTextViewText(TIME_IDS[i], e.time);
                rv.setTextViewText(NAME_IDS[i], e.name);
                rv.setTextViewText(CHECK_IDS[i], "○");
                PendingIntent pi = actionIntent(context, ACTION_COMPLETE, AppWidgetManager.INVALID_APPWIDGET_ID, e.completionKey(), 20000 + i);
                rv.setOnClickPendingIntent(ROW_IDS[i], pi);
                rv.setOnClickPendingIntent(CHECK_IDS[i], pi);
            } else {
                rv.setViewVisibility(ROW_IDS[i], View.GONE);
            }
        }
    }

    private static void bindSurvival(Context context, RemoteViews rv) {
        List<SurvivalItem> surv = WidgetData.survivalForGameDay();
        for (int i = 0; i < SURV_ROW_IDS.length; i++) {
            SurvivalItem s = surv.get(i);
            rv.setViewVisibility(SURV_ROW_IDS[i], View.VISIBLE);
            rv.setTextViewText(SURV_TIME_IDS[i], s.time);
            rv.setTextViewText(SURV_NAME_IDS[i], s.name);
            rv.setInt(SURV_ROW_IDS[i], "setBackgroundResource", s.highlighted ? R.drawable.bg_row_highlight : R.drawable.bg_row);
            rv.setTextColor(SURV_TIME_IDS[i], context.getColor(s.highlighted ? R.color.gold : R.color.text_main));
        }
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id) {
        boolean detail = isDetail(manager, id);
        RemoteViews rv = new RemoteViews(context.getPackageName(), detail ? R.layout.widget_detail : R.layout.widget_compact);

        rv.setTextViewText(R.id.dateText, WidgetData.dateLabel());
        rv.setTextViewText(R.id.updatedText, WidgetData.updatedLabel());
        rv.setOnClickPendingIntent(R.id.resetText, actionIntent(context, ACTION_RESET, id, null, 9000 + id));
        rv.setOnClickPendingIntent(R.id.updatedText, actionIntent(context, ACTION_REFRESH, id, null, 10000 + id));

        bindTodayRows(context, rv);
        bindSurvival(context, rv);

        if (detail) {
            // 4x8 상세형: 둘 다 한 화면에 표시
        } else {
            int page = WidgetData.getCompactPage(context, id);
            boolean showToday = page != 1;
            rv.setViewVisibility(R.id.pageToday, showToday ? View.VISIBLE : View.GONE);
            rv.setViewVisibility(R.id.pageSurvival, showToday ? View.GONE : View.VISIBLE);
            rv.setTextViewText(R.id.sectionTitle, showToday ? "오늘 일정" : "서바이벌 배틀 시간표");
            rv.setTextViewText(R.id.dotToday, showToday ? "●" : "○");
            rv.setTextViewText(R.id.dotSurvival, showToday ? "○" : "●");
            rv.setOnClickPendingIntent(R.id.dotToday, actionIntent(context, ACTION_SHOW_TODAY, id, null, 30000 + id));
            rv.setOnClickPendingIntent(R.id.dotSurvival, actionIntent(context, ACTION_SHOW_SURVIVAL, id, null, 40000 + id));
        }

        manager.updateAppWidget(id, rv);
    }

    private static PendingIntent actionIntent(Context context, String action, int widgetId, String key, int requestCode) {
        Intent i = new Intent(context, TkorWidgetProvider.class);
        i.setAction(action);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        if (key != null) i.putExtra(EXTRA_KEY, key);
        return PendingIntent.getBroadcast(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
