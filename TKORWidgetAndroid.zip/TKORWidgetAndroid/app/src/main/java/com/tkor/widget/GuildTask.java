package com.tkor.widget;

final class GuildTask {
    final String id;
    final String name;

    GuildTask(String id, String name) {
        this.id = id;
        this.name = name;
    }
}
