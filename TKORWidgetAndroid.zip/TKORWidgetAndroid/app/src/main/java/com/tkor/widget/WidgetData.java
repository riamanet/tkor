package com.tkor.widget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class WidgetData {
    static final ZoneId KST = ZoneId.of("Asia/Seoul");
    private static final String PREF = "tkor_widget";
    private static final String EXTRA_JSON = "extra_json";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final String SHEET_URL =
            "https://docs.google.com/spreadsheets/d/1BOc66VJypBulVOXcXrs6K7GqubbE3rWicXT9ReoAols/gviz/tq" +
            "?sheet=%EA%B3%B5%EA%B0%9C%EB%8D%B0%EC%9D%B4%ED%84%B0&range=C2:E1000&tqx=out:json";

    private WidgetData() {}

    static ZonedDateTime now() {
        return ZonedDateTime.now(KST);
    }

    static String dateLabel() {
        ZonedDateTime now = now();
        String[] day = {"일","월","화","수","목","금","토"};
        int idx = now.getDayOfWeek().getValue() % 7;
        return now.getMonthValue() + "월 " + now.getDayOfMonth() + "일 (" + day[idx] + ")";
    }

    static String updatedLabel() {
        return "최종 갱신 " + now().format(DateTimeFormatter.ofPattern("HH:mm")) + " ↻";
    }

    static String todayKey() {
        return now().toLocalDate().toString();
    }

    static List<EventItem> todayEvents(Context context) {
        LocalDate d = now().toLocalDate();
        List<EventItem> all = new ArrayList<>(baseEvents(d));
        all.addAll(extraEvents(context, d));
        Collections.sort(all, Comparator.comparing(e -> e.time));

        Set<String> done = doneSet(context);
        List<EventItem> visible = new ArrayList<>();
        for (EventItem e : all) {
            if (!done.contains(e.completionKey())) visible.add(e);
        }
        return visible;
    }

    private static List<EventItem> baseEvents(LocalDate d) {
        List<EventItem> a = new ArrayList<>();
        LocalDate cheeseStart = LocalDate.of(2026, 9, 20);
        long diff = java.time.temporal.ChronoUnit.DAYS.between(cheeseStart, d);
        if (diff >= 0 && diff % 2 == 0) {
            a.add(new EventItem("19:00", "치즈"));
            a.add(new EventItem("22:00", "치즈"));
        }

        DayOfWeek day = d.getDayOfWeek();
        if (day == DayOfWeek.TUESDAY) a.add(new EventItem("20:30", "좀비포위전"));
        if (day == DayOfWeek.FRIDAY) {
            a.add(new EventItem("20:00", "비약쟁탈전"));
            a.add(new EventItem("20:45", "좀비포위전"));
            a.add(new EventItem("23:00", "왕성쟁탈전"));
        }
        if (day == DayOfWeek.SATURDAY) {
            a.add(new EventItem("10:00", "비약쟁탈전"));
            a.add(new EventItem("23:00", "서버전"));
        }
        if (day == DayOfWeek.SUNDAY) {
            a.add(new EventItem("13:00", "수정골짜기"));
            a.add(new EventItem("20:00", "수정골짜기"));
        }
        if (day == DayOfWeek.MONDAY) {
            a.add(new EventItem("05:00", "수정골짜기"));
            a.add(new EventItem("10:00", "수정골짜기"));
        }
        return a;
    }


    static int getCompactPage(Context context, int widgetId) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getInt("page_" + widgetId, 0);
    }

    static void setCompactPage(Context context, int widgetId, int page) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putInt("page_" + widgetId, page).apply();
    }

    static void clearPageState(Context context, int widgetId) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().remove("page_" + widgetId).apply();
    }

    static Set<String> doneSet(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        return new HashSet<>(sp.getStringSet("done_" + todayKey(), Collections.emptySet()));
    }

    static void markDone(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Set<String> set = new HashSet<>(sp.getStringSet("done_" + todayKey(), Collections.emptySet()));
        set.add(key);
        sp.edit().putStringSet("done_" + todayKey(), set).apply();
    }

    static void resetToday(Context context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().remove("done_" + todayKey()).apply();
    }

    static List<SurvivalItem> survivalForGameDay() {
        // 게임 기준 하루는 한국시간 11:00에 바뀜.
        DayOfWeek d = now().minusHours(11).getDayOfWeek();
        switch (d) {
            case MONDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","영웅 강화",true},{"15:00 ~ 19:00","영지 건설",false},{"19:00 ~ 23:00","병사 훈련",false},{"23:00 ~ 03:00","기술 연구",false},{"03:00 ~ 07:00","까마귀 강화",true},{"07:00 ~ 11:00","영웅 강화",true}});
            case TUESDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","영지 건설",true},{"15:00 ~ 19:00","병사 훈련",false},{"19:00 ~ 23:00","기술 연구",false},{"23:00 ~ 03:00","까마귀 강화",false},{"03:00 ~ 07:00","영웅 강화",false},{"07:00 ~ 11:00","영지 건설",true}});
            case WEDNESDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","병사 훈련",false},{"15:00 ~ 19:00","기술 연구",true},{"19:00 ~ 23:00","까마귀 강화",false},{"23:00 ~ 03:00","영웅 강화",false},{"03:00 ~ 07:00","영지 건설",false},{"07:00 ~ 11:00","병사 훈련",false}});
            case THURSDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","기술 연구",false},{"15:00 ~ 19:00","까마귀 강화",false},{"19:00 ~ 23:00","영웅 강화",true},{"23:00 ~ 03:00","영지 건설",false},{"03:00 ~ 07:00","병사 훈련",false},{"07:00 ~ 11:00","기술 연구",false}});
            case FRIDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","까마귀 강화",false},{"15:00 ~ 19:00","영웅 강화",false},{"19:00 ~ 23:00","영지 건설",true},{"23:00 ~ 03:00","병사 훈련",true},{"03:00 ~ 07:00","기술 연구",true},{"07:00 ~ 11:00","까마귀 강화",false}});
            case SATURDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","영웅 강화",false},{"15:00 ~ 19:00","영지 건설",true},{"19:00 ~ 23:00","병사 훈련",true},{"23:00 ~ 03:00","기술 연구",true},{"03:00 ~ 07:00","까마귀 강화",false},{"07:00 ~ 11:00","영웅 강화",false}});
            default:
                return s(new Object[][]{{"11:00 ~ 15:00","영지 건설",false},{"15:00 ~ 19:00","병사 훈련",false},{"19:00 ~ 23:00","기술 연구",false},{"23:00 ~ 03:00","까마귀 강화",false},{"03:00 ~ 07:00","영웅 강화",false},{"07:00 ~ 11:00","영지 건설",false}});
        }
    }

    private static List<SurvivalItem> s(Object[][] rows) {
        List<SurvivalItem> out = new ArrayList<>();
        for (Object[] r : rows) out.add(new SurvivalItem((String) r[0], (String) r[1], (Boolean) r[2]));
        return out;
    }

    static void refreshExtrasAsync(Context context, Runnable done) {
        IO.execute(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(SHEET_URL).openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("User-Agent", "TKORWidget/1.0");
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
                String body = sb.toString();
                int first = body.indexOf('{');
                int last = body.lastIndexOf('}');
                if (first >= 0 && last > first) {
                    JSONObject root = new JSONObject(body.substring(first, last + 1));
                    JSONArray rows = root.optJSONObject("table").optJSONArray("rows");
                    JSONArray store = new JSONArray();
                    if (rows != null) {
                        for (int i = 0; i < rows.length(); i++) {
                            JSONArray c = rows.optJSONObject(i).optJSONArray("c");
                            if (c == null || c.length() < 3) continue;
                            String name = cell(c.optJSONObject(0));
                            String date = normalizeDate(c.optJSONObject(1));
                            String time = normalizeTime(c.optJSONObject(2));
                            if (name.isEmpty() || date.isEmpty() || time.isEmpty()) continue;
                            JSONObject o = new JSONObject();
                            o.put("name", name);
                            o.put("date", date);
                            o.put("time", time);
                            store.put(o);
                        }
                    }
                    context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(EXTRA_JSON, store.toString()).apply();
                }
            } catch (Exception ignored) {
                // 네트워크 실패 시 마지막 캐시를 그대로 사용.
            } finally {
                if (done != null) done.run();
            }
        });
    }

    private static String cell(JSONObject cell) {
        if (cell == null) return "";
        String f = cell.optString("f", "").trim();
        if (!f.isEmpty()) return f;
        Object v = cell.opt("v");
        return v == null ? "" : String.valueOf(v).trim();
    }

    private static String normalizeDate(JSONObject cell) {
        if (cell == null) return "";
        String raw = String.valueOf(cell.opt("v"));
        if (raw.startsWith("Date(")) {
            try {
                String[] p = raw.substring(5, raw.length() - 1).split(",");
                int y = Integer.parseInt(p[0].trim());
                int m = Integer.parseInt(p[1].trim()) + 1;
                int d = Integer.parseInt(p[2].trim());
                return String.format(Locale.US, "%04d-%02d-%02d", y, m, d);
            } catch (Exception ignored) {}
        }
        String s = cell(cell);
        String[] nums = s.replaceAll("[^0-9]+", " ").trim().split("\\s+");
        try {
            if (nums.length >= 3) {
                int a = Integer.parseInt(nums[0]);
                int b = Integer.parseInt(nums[1]);
                int c = Integer.parseInt(nums[2]);
                if (a > 1900) return String.format(Locale.US, "%04d-%02d-%02d", a, b, c);
                if (c > 1900) return String.format(Locale.US, "%04d-%02d-%02d", c, a, b);
            }
        } catch (Exception ignored) {}
        return "";
    }

    private static String normalizeTime(JSONObject cell) {
        String s = cell(cell);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,2}):(\\d{2})").matcher(s);
        if (m.find()) return String.format(Locale.US, "%02d:%02d", Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)));
        return "";
    }

    private static List<EventItem> extraEvents(Context context, LocalDate today) {
        String json = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(EXTRA_JSON, "[]");
        List<EventItem> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(json);
            String key = today.toString();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (key.equals(o.optString("date"))) {
                    out.add(new EventItem(o.optString("time"), o.optString("name")));
                }
            }
        } catch (Exception ignored) {}
        return out;
    }
}
