TKOR native app variant

- This is NOT a WebView wrapper.
- Launcher opens a native Android screen.
- Native tabs: 일정 / 길드전 / 공지.
- Uses the same WidgetData and SharedPreferences as the home-screen widget.
- Today-only events and notice board are loaded directly from the public Google Sheet data.
- Existing widget remains available.
- Added compact-short layout for launchers that give less vertical widget space.
- The 제보하기 button opens the existing Google Form externally; core schedule/check/notice UI is native.
