package com.tkor.widget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TkorWidgetProvider extends AppWidgetProvider {

    static void requestRefresh(Context context) {
        updateAll(context.getApplicationContext());
    }
    private static final String ACTION_COMPLETE = "com.tkor.widget.COMPLETE";
    private static final String ACTION_RESET = "com.tkor.widget.RESET";
    private static final String ACTION_REFRESH = "com.tkor.widget.REFRESH";
    private static final String ACTION_SHOW_TODAY = "com.tkor.widget.SHOW_TODAY";
    private static final String ACTION_SHOW_SURVIVAL = "com.tkor.widget.SHOW_SURVIVAL";
    private static final String ACTION_SHOW_GUILD = "com.tkor.widget.SHOW_GUILD";
    private static final String ACTION_GUILD_TOGGLE = "com.tkor.widget.GUILD_TOGGLE";
    private static final String ACTION_GUILD_RESET = "com.tkor.widget.GUILD_RESET";
    private static final String ACTION_SHIELD_8 = "com.tkor.widget.SHIELD_8";
    private static final String ACTION_SHIELD_12 = "com.tkor.widget.SHIELD_12";
    private static final String ACTION_SHIELD_START = "com.tkor.widget.SHIELD_START";
    private static final String ACTION_SHIELD_EXPIRED = "com.tkor.widget.SHIELD_EXPIRED";
    private static final String ACTION_GAME_DAY_ROLLOVER = "com.tkor.widget.GAME_DAY_ROLLOVER";
    private static final String ACTION_TODAY_EVENT_EXPIRED = "com.tkor.widget.TODAY_EVENT_EXPIRED";
    private static final String EXTRA_KEY = "completion_key";

    private static final int[] ROW_IDS = {R.id.row1,R.id.row2,R.id.row3,R.id.row4,R.id.row5,R.id.row6,R.id.row7};
    private static final int[] TIME_IDS = {R.id.time1,R.id.time2,R.id.time3,R.id.time4,R.id.time5,R.id.time6,R.id.time7};
    private static final int[] NAME_IDS = {R.id.name1,R.id.name2,R.id.name3,R.id.name4,R.id.name5,R.id.name6,R.id.name7};
    private static final int[] CHECK_IDS = {R.id.check1,R.id.check2,R.id.check3,R.id.check4,R.id.check5,R.id.check6,R.id.check7};

    private static final int[] SURV_ROW_IDS = {R.id.survRow1,R.id.survRow2,R.id.survRow3,R.id.survRow4,R.id.survRow5,R.id.survRow6};
    private static final int[] SURV_TIME_IDS = {R.id.survTime1,R.id.survTime2,R.id.survTime3,R.id.survTime4,R.id.survTime5,R.id.survTime6};
    private static final int[] SURV_NAME_IDS = {R.id.survName1,R.id.survName2,R.id.survName3,R.id.survName4,R.id.survName5,R.id.survName6};

    private static final int[] GUILD_ROW_IDS = {R.id.guildRow1,R.id.guildRow2,R.id.guildRow3,R.id.guildRow4,R.id.guildRow5,R.id.guildRow6};
    private static final int[] GUILD_CHECK_IDS = {R.id.guildCheck1,R.id.guildCheck2,R.id.guildCheck3,R.id.guildCheck4,R.id.guildCheck5,R.id.guildCheck6};
    private static final int[] GUILD_NAME_IDS = {R.id.guildName1,R.id.guildName2,R.id.guildName3,R.id.guildName4,R.id.guildName5,R.id.guildName6};

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateOne(context, manager, id);
        scheduleNextGameDayRollover(context);
        scheduleNextTodayEventExpiry(context);
        WidgetData.refreshExtrasAsync(context, () -> {
            updateAll(context);
            scheduleNextTodayEventExpiry(context);
        });
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        scheduleNextGameDayRollover(context);
        scheduleNextTodayEventExpiry(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int appWidgetId, Bundle newOptions) {
        updateOne(context, manager, appWidgetId);
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        for (int id : appWidgetIds) WidgetData.clearPageState(context, id);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        int widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (ACTION_COMPLETE.equals(action)) {
            String key = intent.getStringExtra(EXTRA_KEY);
            if (key != null) WidgetData.markDone(context, key);
            updateAll(context);
            return;
        }
        if (ACTION_RESET.equals(action)) {
            WidgetData.resetToday(context);
            updateAll(context);
            return;
        }
        if (ACTION_GUILD_TOGGLE.equals(action)) {
            String key = intent.getStringExtra(EXTRA_KEY);
            if (key != null) WidgetData.toggleGuildDone(context, key);
            updateAll(context);
            return;
        }
        if (ACTION_GUILD_RESET.equals(action)) {
            WidgetData.resetGuildToday(context);
            updateAll(context);
            return;
        }
        if (ACTION_SHOW_TODAY.equals(action) && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            WidgetData.setCompactPage(context, widgetId, 0);
            updateOne(context, AppWidgetManager.getInstance(context), widgetId);
            return;
        }
        if (ACTION_SHOW_SURVIVAL.equals(action) && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            WidgetData.setCompactPage(context, widgetId, 1);
            updateOne(context, AppWidgetManager.getInstance(context), widgetId);
            return;
        }
        if (ACTION_SHOW_GUILD.equals(action) && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            WidgetData.setCompactPage(context, widgetId, 2);
            updateOne(context, AppWidgetManager.getInstance(context), widgetId);
            return;
        }
        if (ACTION_SHIELD_8.equals(action)) {
            WidgetData.setShieldHours(context, 8);
            updateAll(context);
            return;
        }
        if (ACTION_SHIELD_12.equals(action)) {
            WidgetData.setShieldHours(context, 12);
            updateAll(context);
            return;
        }
        if (ACTION_SHIELD_START.equals(action)) {
            long end = WidgetData.startShield(context);
            scheduleShieldEnd(context, end);
            updateAll(context);
            return;
        }
        if (ACTION_SHIELD_EXPIRED.equals(action)) {
            updateAll(context);
            return;
        }
        if (ACTION_GAME_DAY_ROLLOVER.equals(action)) {
            // 11:00 KST가 되면 오늘 일정/길드전/체크 기준을 새 게임 날짜로 전환한다.
            updateAll(context);
            scheduleNextGameDayRollover(context);
            scheduleNextTodayEventExpiry(context);
            return;
        }
        if (ACTION_TODAY_EVENT_EXPIRED.equals(action)) {
            // 일반 일정은 시작 1시간 뒤 자동으로 목록에서 숨긴다.
            updateAll(context);
            scheduleNextTodayEventExpiry(context);
            return;
        }
        if (ACTION_REFRESH.equals(action)) {
            final PendingResult result = goAsync();
            WidgetData.refreshExtrasAsync(context, () -> {
                updateAll(context);
                scheduleNextTodayEventExpiry(context);
                result.finish();
            });
            return;
        }
        super.onReceive(context, intent);
    }


    private static void scheduleNextGameDayRollover(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;

        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Seoul"));
        ZonedDateTime next = now.withHour(11).withMinute(0).withSecond(0).withNano(0);
        if (!next.isAfter(now)) next = next.plusDays(1);

        Intent i = new Intent(context, TkorWidgetProvider.class).setAction(ACTION_GAME_DAY_ROLLOVER);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 77111, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        long triggerAt = next.toInstant().toEpochMilli();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms()) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        } else {
            // 정확 알람 권한이 없어도 11시 무렵에는 자동 갱신되도록 예약한다.
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }


    private static void scheduleNextTodayEventExpiry(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;

        Intent i = new Intent(context, TkorWidgetProvider.class).setAction(ACTION_TODAY_EVENT_EXPIRED);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 77112, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        long triggerAt = WidgetData.nextTodayExpiryMillis(context);
        if (triggerAt <= System.currentTimeMillis()) {
            alarm.cancel(pi);
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms()) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        } else {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }

    private static void scheduleShieldEnd(Context context, long endMillis) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        Intent i = new Intent(context, TkorWidgetProvider.class).setAction(ACTION_SHIELD_EXPIRED);
        PendingIntent pi = PendingIntent.getBroadcast(context, 77117, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        alarm.set(AlarmManager.RTC_WAKEUP, endMillis, pi);
    }

    private static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, TkorWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    private static boolean isDetail(AppWidgetManager manager, int id) {
        Bundle options = manager.getAppWidgetOptions(id);
        int h = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
        int w = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        if (w > 0 && h > 0) return h >= (int) (w * 1.75f);
        return h >= 600;
    }

    /**
     * Return the widget height for the current orientation.
     * Android launchers usually report minHeight for landscape and maxHeight for portrait.
     * Using minHeight unconditionally made portrait widgets choose an unnecessarily tiny layout.
     */
    private static int compactHeight(Context context, AppWidgetManager manager, int id) {
        Bundle options = manager.getAppWidgetOptions(id);
        int minHeight = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
        int maxHeight = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);

        // Use the host's guaranteed minimum height as the safe current-size baseline.
        // Some launchers report a much larger maxHeight for another orientation/bound;
        // using that value made the rows too tall and pushed the last row under the footer.
        if (minHeight > 0) return minHeight;
        return maxHeight;
    }

    private static boolean isTinyCompact(Context context, AppWidgetManager manager, int id) {
        int h = compactHeight(context, manager, id);
        return h > 0 && h < 315;
    }

    private static boolean isShortCompact(Context context, AppWidgetManager manager, int id) {
        int h = compactHeight(context, manager, id);
        return h > 0 && h < 375;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static int dpPx(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    /**
     * Android 12+ lets RemoteViews change dimensions at update time.  We use the actual
     * widget height to size rows, while reserving a fixed footer zone for the brand and dots.
     * This keeps the same composition on Samsung/Pixel/etc. without clipping the bottom.
     */
    private static void applyResponsiveCompactSizing(Context context, AppWidgetManager manager,
                                                      int id, RemoteViews rv, int page) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;

        int h = compactHeight(context, manager, id);
        if (h <= 0) h = 380;

        int todayCount = Math.min(ROW_IDS.length, WidgetData.todayEvents(context).size());
        int rowSlots;
        float reserve;
        if (page == 0) {
            // Keep the reference look: 4-5 events stay near the top and the remaining area is blank.
            rowSlots = Math.max(6, Math.max(1, todayCount));
            reserve = 145f;
        } else if (page == 1) {
            rowSlots = 6;
            reserve = 145f;
        } else {
            rowSlots = 6;
            // Guild page has a note under the rows; Saturday also has the shield panel.
            reserve = WidgetData.isSaturdayGameDay() ? 220f : 168f;
        }

        // Reserve extra room for launcher-internal padding. Most importantly, do not force
        // rows to a 24dp minimum: on a 4x4 Samsung widget six 24dp rows can exceed the real
        // content area and clip the last row behind the footer.
        float usableHeight = Math.max(170f, h - 16f);
        float rowDp = clamp((usableHeight - reserve) / rowSlots, 10f, 46f);

        // Text follows the actual row height. COMPLEX_UNIT_DIP is intentional so a user's
        // system font-scale setting does not make this widget layout different from others.
        float logoSp = h < 315 ? 30f : (h < 375 ? 34f : 40f);
        float titleSp = h < 315 ? 20f : (h < 375 ? 23f : 27f);
        float mainSp = rowDp < 14f ? 9f : (rowDp < 18f ? 10.5f : (rowDp < 24f ? 12f : (rowDp < 35f ? 14f : (rowDp < 42f ? 16f : 18f))));
        float checkSp = rowDp < 14f ? 11f : (rowDp < 18f ? 14f : (rowDp < 24f ? 17f : (rowDp < 36f ? 21f : 25f)));
        float footerSp = h < 315 ? 7f : 9f;
        float dotSp = h < 315 ? 11f : 14f;

        // All compact pages share these IDs, so one sizing pass keeps every page consistent.
        rv.setTextViewTextSize(R.id.logoText, TypedValue.COMPLEX_UNIT_DIP, logoSp);
        rv.setTextViewTextSize(R.id.sectionTitle, TypedValue.COMPLEX_UNIT_DIP, titleSp);
        rv.setTextViewTextSize(R.id.dateText, TypedValue.COMPLEX_UNIT_DIP, h < 315 ? 13f : 16f);
        rv.setTextViewTextSize(R.id.updatedText, TypedValue.COMPLEX_UNIT_DIP, h < 315 ? 10f : 12f);
        rv.setTextViewTextSize(R.id.resetText, TypedValue.COMPLEX_UNIT_DIP, h < 315 ? 10f : 12f);
        rv.setTextViewTextSize(R.id.footerBrand, TypedValue.COMPLEX_UNIT_DIP, footerSp);
        rv.setTextViewTextSize(R.id.dotToday, TypedValue.COMPLEX_UNIT_DIP, dotSp);
        rv.setTextViewTextSize(R.id.dotSurvival, TypedValue.COMPLEX_UNIT_DIP, dotSp);
        rv.setTextViewTextSize(R.id.dotGuild, TypedValue.COMPLEX_UNIT_DIP, dotSp);

        // The TKOR logo has no id in the old XML.  Section/header sizing plus row sizing is enough
        // to avoid clipping; root/footer padding is reduced only on genuinely short widgets.
        int topPad = h < 315 ? 9 : (h < 375 ? 12 : 16);
        int bottomPad = h < 315 ? 7 : (h < 375 ? 9 : 12);
        rv.setViewPadding(R.id.widgetRoot, dpPx(context, 18), dpPx(context, topPad),
                dpPx(context, 18), dpPx(context, bottomPad));
        rv.setViewPadding(R.id.footerBrand, 0, dpPx(context, h < 315 ? 3 : 6), 0, 0);
        rv.setViewPadding(R.id.pagerDots, 0, dpPx(context, h < 315 ? 2 : 5), 0, 0);

        for (int i = 0; i < ROW_IDS.length; i++) {
            rv.setViewLayoutHeight(ROW_IDS[i], rowDp, TypedValue.COMPLEX_UNIT_DIP);
            rv.setTextViewTextSize(CHECK_IDS[i], TypedValue.COMPLEX_UNIT_DIP, checkSp);
            rv.setTextViewTextSize(TIME_IDS[i], TypedValue.COMPLEX_UNIT_DIP, mainSp);
            rv.setTextViewTextSize(NAME_IDS[i], TypedValue.COMPLEX_UNIT_DIP, mainSp);
        }
        for (int i = 0; i < SURV_ROW_IDS.length; i++) {
            rv.setViewLayoutHeight(SURV_ROW_IDS[i], rowDp, TypedValue.COMPLEX_UNIT_DIP);
            rv.setTextViewTextSize(SURV_TIME_IDS[i], TypedValue.COMPLEX_UNIT_DIP, mainSp);
            rv.setTextViewTextSize(SURV_NAME_IDS[i], TypedValue.COMPLEX_UNIT_DIP, mainSp);
        }
        for (int i = 0; i < GUILD_ROW_IDS.length; i++) {
            rv.setViewLayoutHeight(GUILD_ROW_IDS[i], rowDp, TypedValue.COMPLEX_UNIT_DIP);
            rv.setTextViewTextSize(GUILD_CHECK_IDS[i], TypedValue.COMPLEX_UNIT_DIP, checkSp);
            rv.setTextViewTextSize(GUILD_NAME_IDS[i], TypedValue.COMPLEX_UNIT_DIP, mainSp);
        }
    }

    private static void bindTodayRows(Context context, RemoteViews rv) {
        List<EventItem> events = WidgetData.todayEvents(context);
        for (int i = 0; i < ROW_IDS.length; i++) {
            if (i < events.size()) {
                EventItem e = events.get(i);
                rv.setViewVisibility(ROW_IDS[i], View.VISIBLE);
                rv.setTextViewText(TIME_IDS[i], e.time);
                rv.setTextViewText(NAME_IDS[i], e.name);
                rv.setTextViewText(CHECK_IDS[i], "○");
                PendingIntent pi = actionIntent(context, ACTION_COMPLETE, AppWidgetManager.INVALID_APPWIDGET_ID, e.completionKey(), 20000 + i);
                rv.setOnClickPendingIntent(ROW_IDS[i], pi);
                rv.setOnClickPendingIntent(CHECK_IDS[i], pi);
            } else {
                rv.setViewVisibility(ROW_IDS[i], View.GONE);
            }
        }
    }

    private static void bindSurvival(Context context, RemoteViews rv) {
        List<SurvivalItem> surv = WidgetData.survivalForGameDay();
        for (int i = 0; i < SURV_ROW_IDS.length; i++) {
            SurvivalItem s = surv.get(i);
            rv.setViewVisibility(SURV_ROW_IDS[i], View.VISIBLE);
            rv.setTextViewText(SURV_TIME_IDS[i], s.time);
            rv.setTextViewText(SURV_NAME_IDS[i], s.name);
            rv.setInt(SURV_ROW_IDS[i], "setBackgroundResource", s.highlighted ? R.drawable.bg_row_highlight : R.drawable.bg_row);
            rv.setTextColor(SURV_TIME_IDS[i], context.getColor(s.highlighted ? R.color.gold : R.color.text_main));
        }
    }

    private static void bindGuild(Context context, RemoteViews rv) {
        rv.setTextViewText(R.id.guildDayText, WidgetData.guildDayLabel());
        rv.setTextViewText(R.id.guildNoteText, WidgetData.guildNoteForGameDay());

        boolean saturday = WidgetData.isSaturdayGameDay();
        rv.setViewVisibility(R.id.shieldPanel, saturday ? View.VISIBLE : View.GONE);
        if (saturday) bindShield(context, rv);

        List<GuildTask> tasks = WidgetData.guildTasksForGameDay();
        for (int i = 0; i < GUILD_ROW_IDS.length; i++) {
            if (i < tasks.size()) {
                GuildTask task = tasks.get(i);
                boolean done = WidgetData.isGuildDone(context, task.id);
                rv.setViewVisibility(GUILD_ROW_IDS[i], View.VISIBLE);
                rv.setTextViewText(GUILD_CHECK_IDS[i], done ? "✓" : "○");
                rv.setTextColor(GUILD_CHECK_IDS[i], context.getColor(done ? R.color.gold : R.color.text_muted));
                rv.setTextViewText(GUILD_NAME_IDS[i], task.name);
                PendingIntent pi = actionIntent(context, ACTION_GUILD_TOGGLE, AppWidgetManager.INVALID_APPWIDGET_ID, task.id, 50000 + i);
                rv.setOnClickPendingIntent(GUILD_ROW_IDS[i], pi);
                rv.setOnClickPendingIntent(GUILD_CHECK_IDS[i], pi);
            } else {
                rv.setViewVisibility(GUILD_ROW_IDS[i], View.GONE);
            }
        }
    }

    private static void bindShield(Context context, RemoteViews rv) {
        int hours = WidgetData.shieldHours(context);
        rv.setInt(R.id.shield8, "setBackgroundResource", hours == 8 ? R.drawable.bg_row_highlight : R.drawable.bg_reset);
        rv.setInt(R.id.shield12, "setBackgroundResource", hours == 12 ? R.drawable.bg_row_highlight : R.drawable.bg_reset);
        rv.setTextColor(R.id.shield8, context.getColor(hours == 8 ? R.color.gold : R.color.text_main));
        rv.setTextColor(R.id.shield12, context.getColor(hours == 12 ? R.color.gold : R.color.text_main));
        rv.setOnClickPendingIntent(R.id.shield8, actionIntent(context, ACTION_SHIELD_8, AppWidgetManager.INVALID_APPWIDGET_ID, null, 61008));
        rv.setOnClickPendingIntent(R.id.shield12, actionIntent(context, ACTION_SHIELD_12, AppWidgetManager.INVALID_APPWIDGET_ID, null, 61012));
        rv.setOnClickPendingIntent(R.id.shieldStart, actionIntent(context, ACTION_SHIELD_START, AppWidgetManager.INVALID_APPWIDGET_ID, null, 61100));

        long end = WidgetData.shieldEndMillis(context);
        long remaining = end - System.currentTimeMillis();
        if (remaining > 0) {
            long base = SystemClock.elapsedRealtime() + remaining;
            rv.setViewVisibility(R.id.shieldTimer, View.VISIBLE);
            rv.setChronometer(R.id.shieldTimer, base, null, true);
            rv.setChronometerCountDown(R.id.shieldTimer, true);
            String endText = Instant.ofEpochMilli(end).atZone(ZoneId.of("Asia/Seoul"))
                    .format(DateTimeFormatter.ofPattern("HH:mm"));
            rv.setTextViewText(R.id.shieldStatus, "갱신 " + endText + " · " + hours + "시간");
            rv.setTextViewText(R.id.shieldStart, "다시 시작");
        } else {
            rv.setViewVisibility(R.id.shieldTimer, View.GONE);
            rv.setTextViewText(R.id.shieldStatus, "시간 선택 후 보호막 시작");
            rv.setTextViewText(R.id.shieldStart, "보호막 시작");
        }
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id) {
        boolean detail = isDetail(manager, id);
        boolean tinyCompact = !detail && isTinyCompact(context, manager, id);
        boolean shortCompact = !detail && !tinyCompact && isShortCompact(context, manager, id);
        int layoutId;
        if (detail) {
            layoutId = R.layout.widget_detail;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            layoutId = R.layout.widget_compact;
        } else {
            layoutId = tinyCompact ? R.layout.widget_compact_tiny
                    : (shortCompact ? R.layout.widget_compact_short : R.layout.widget_compact);
        }
        RemoteViews rv = new RemoteViews(context.getPackageName(), layoutId);

        rv.setTextViewText(R.id.dateText, WidgetData.dateLabel());
        rv.setTextViewText(R.id.updatedText, WidgetData.updatedLabel());
        rv.setOnClickPendingIntent(R.id.updatedText, actionIntent(context, ACTION_REFRESH, id, null, 10000 + id));

        bindTodayRows(context, rv);
        bindSurvival(context, rv);

        if (detail) {
            // 세로 상세형은 기존처럼 오늘 일정 + 서바이벌 배틀만 표시한다.
            rv.setTextViewText(R.id.resetText, "초기화");
            rv.setOnClickPendingIntent(R.id.resetText, actionIntent(context, ACTION_RESET, id, null, 9000 + id));
        } else {
            bindGuild(context, rv);
            int page = WidgetData.getCompactPage(context, id);
            if (page < 0 || page > 2) page = 0;
            boolean today = page == 0;
            boolean survival = page == 1;
            boolean guild = page == 2;

            applyResponsiveCompactSizing(context, manager, id, rv, page);

            rv.setViewVisibility(R.id.pageToday, today ? View.VISIBLE : View.GONE);
            rv.setViewVisibility(R.id.pageSurvival, survival ? View.VISIBLE : View.GONE);
            rv.setViewVisibility(R.id.pageGuild, guild ? View.VISIBLE : View.GONE);
            rv.setTextViewText(R.id.sectionTitle, today ? "오늘 일정" : (survival ? "서바이벌 배틀" : "길드전"));
            rv.setTextViewText(R.id.dotToday, today ? "●" : "○");
            rv.setTextViewText(R.id.dotSurvival, survival ? "●" : "○");
            rv.setTextViewText(R.id.dotGuild, guild ? "●" : "○");
            rv.setTextColor(R.id.dotToday, context.getColor(today ? R.color.text_main : R.color.text_muted));
            rv.setTextColor(R.id.dotSurvival, context.getColor(survival ? R.color.text_main : R.color.text_muted));
            rv.setTextColor(R.id.dotGuild, context.getColor(guild ? R.color.text_main : R.color.text_muted));

            rv.setOnClickPendingIntent(R.id.dotToday, actionIntent(context, ACTION_SHOW_TODAY, id, null, 30000 + id));
            rv.setOnClickPendingIntent(R.id.dotSurvival, actionIntent(context, ACTION_SHOW_SURVIVAL, id, null, 40000 + id));
            rv.setOnClickPendingIntent(R.id.dotGuild, actionIntent(context, ACTION_SHOW_GUILD, id, null, 45000 + id));

            rv.setTextViewText(R.id.resetText, guild ? "길드 초기화" : "초기화");
            rv.setOnClickPendingIntent(R.id.resetText, actionIntent(context, guild ? ACTION_GUILD_RESET : ACTION_RESET, id, null, 9000 + id));
        }

        manager.updateAppWidget(id, rv);
    }

    private static PendingIntent actionIntent(Context context, String action, int widgetId, String key, int requestCode) {
        Intent i = new Intent(context, TkorWidgetProvider.class);
        i.setAction(action);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        if (key != null) i.putExtra(EXTRA_KEY, key);
        return PendingIntent.getBroadcast(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
