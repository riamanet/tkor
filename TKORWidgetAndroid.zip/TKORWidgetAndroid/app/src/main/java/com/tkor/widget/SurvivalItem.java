package com.tkor.widget;

final class SurvivalItem {
    final String time;
    final String name;
    final boolean highlighted;

    SurvivalItem(String time, String name, boolean highlighted) {
        this.time = time;
        this.name = name;
        this.highlighted = highlighted;
    }
}
