package com.tkor.widget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.RemoteViews;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TkorWidgetProvider extends AppWidgetProvider {

    static void requestRefresh(Context context) {
        updateAll(context.getApplicationContext());
    }
    private static final String ACTION_COMPLETE = "com.tkor.widget.COMPLETE";
    private static final String ACTION_RESET = "com.tkor.widget.RESET";
    private static final String ACTION_REFRESH = "com.tkor.widget.REFRESH";
    private static final String ACTION_SHOW_TODAY = "com.tkor.widget.SHOW_TODAY";
    private static final String ACTION_SHOW_SURVIVAL = "com.tkor.widget.SHOW_SURVIVAL";
    private static final String ACTION_SHOW_GUILD = "com.tkor.widget.SHOW_GUILD";
    private static final String ACTION_GUILD_TOGGLE = "com.tkor.widget.GUILD_TOGGLE";
    private static final String ACTION_GUILD_RESET = "com.tkor.widget.GUILD_RESET";
    private static final String ACTION_SHIELD_8 = "com.tkor.widget.SHIELD_8";
    private static final String ACTION_SHIELD_12 = "com.tkor.widget.SHIELD_12";
    private static final String ACTION_SHIELD_START = "com.tkor.widget.SHIELD_START";
    private static final String ACTION_SHIELD_EXPIRED = "com.tkor.widget.SHIELD_EXPIRED";
    private static final String ACTION_GAME_DAY_ROLLOVER = "com.tkor.widget.GAME_DAY_ROLLOVER";
    private static final String ACTION_TODAY_EVENT_EXPIRED = "com.tkor.widget.TODAY_EVENT_EXPIRED";
    private static final String EXTRA_KEY = "completion_key";

    private static final int[] ROW_IDS = {R.id.row1,R.id.row2,R.id.row3,R.id.row4,R.id.row5,R.id.row6,R.id.row7};
    private static final int[] TIME_IDS = {R.id.time1,R.id.time2,R.id.time3,R.id.time4,R.id.time5,R.id.time6,R.id.time7};
    private static final int[] NAME_IDS = {R.id.name1,R.id.name2,R.id.name3,R.id.name4,R.id.name5,R.id.name6,R.id.name7};
    private static final int[] CHECK_IDS = {R.id.check1,R.id.check2,R.id.check3,R.id.check4,R.id.check5,R.id.check6,R.id.check7};

    private static final int[] SURV_ROW_IDS = {R.id.survRow1,R.id.survRow2,R.id.survRow3,R.id.survRow4,R.id.survRow5,R.id.survRow6};
    private static final int[] SURV_TIME_IDS = {R.id.survTime1,R.id.survTime2,R.id.survTime3,R.id.survTime4,R.id.survTime5,R.id.survTime6};
    private static final int[] SURV_NAME_IDS = {R.id.survName1,R.id.survName2,R.id.survName3,R.id.survName4,R.id.survName5,R.id.survName6};

    private static final int[] GUILD_ROW_IDS = {R.id.guildRow1,R.id.guildRow2,R.id.guildRow3,R.id.guildRow4,R.id.guildRow5,R.id.guildRow6};
    private static final int[] GUILD_CHECK_IDS = {R.id.guildCheck1,R.id.guildCheck2,R.id.guildCheck3,R.id.guildCheck4,R.id.guildCheck5,R.id.guildCheck6};
    private static final int[] GUILD_NAME_IDS = {R.id.guildName1,R.id.guildName2,R.id.guildName3,R.id.guildName4,R.id.guildName5,R.id.guildName6};

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateOne(context, manager, id);
        scheduleNextGameDayRollover(context);
        scheduleNextTodayEventExpiry(context);
        WidgetData.refreshExtrasAsync(context, () -> {
            updateAll(context);
            scheduleNextTodayEventExpiry(context);
        });
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        scheduleNextGameDayRollover(context);
        scheduleNextTodayEventExpiry(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int appWidgetId, Bundle newOptions) {
        updateOne(context, manager, appWidgetId);
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        for (int id : appWidgetIds) WidgetData.clearPageState(context, id);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        int widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (ACTION_COMPLETE.equals(action)) {
            String key = intent.getStringExtra(EXTRA_KEY);
            if (key != null) WidgetData.markDone(context, key);
            updateAll(context);
            return;
        }
        if (ACTION_RESET.equals(action)) {
            WidgetData.resetToday(context);
            updateAll(context);
            return;
        }
        if (ACTION_GUILD_TOGGLE.equals(action)) {
            String key = intent.getStringExtra(EXTRA_KEY);
            if (key != null) WidgetData.toggleGuildDone(context, key);
            updateAll(context);
            return;
        }
        if (ACTION_GUILD_RESET.equals(action)) {
            WidgetData.resetGuildToday(context);
            updateAll(context);
            return;
        }
        if (ACTION_SHOW_TODAY.equals(action) && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            WidgetData.setCompactPage(context, widgetId, 0);
            updateOne(context, AppWidgetManager.getInstance(context), widgetId);
            return;
        }
        if (ACTION_SHOW_SURVIVAL.equals(action) && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            WidgetData.setCompactPage(context, widgetId, 1);
            updateOne(context, AppWidgetManager.getInstance(context), widgetId);
            return;
        }
        if (ACTION_SHOW_GUILD.equals(action) && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            WidgetData.setCompactPage(context, widgetId, 2);
            updateOne(context, AppWidgetManager.getInstance(context), widgetId);
            return;
        }
        if (ACTION_SHIELD_8.equals(action)) {
            WidgetData.setShieldHours(context, 8);
            updateAll(context);
            return;
        }
        if (ACTION_SHIELD_12.equals(action)) {
            WidgetData.setShieldHours(context, 12);
            updateAll(context);
            return;
        }
        if (ACTION_SHIELD_START.equals(action)) {
            long end = WidgetData.startShield(context);
            scheduleShieldEnd(context, end);
            updateAll(context);
            return;
        }
        if (ACTION_SHIELD_EXPIRED.equals(action)) {
            updateAll(context);
            return;
        }
        if (ACTION_GAME_DAY_ROLLOVER.equals(action)) {
            // 11:00 KST가 되면 오늘 일정/길드전/체크 기준을 새 게임 날짜로 전환한다.
            updateAll(context);
            scheduleNextGameDayRollover(context);
            scheduleNextTodayEventExpiry(context);
            return;
        }
        if (ACTION_TODAY_EVENT_EXPIRED.equals(action)) {
            // 일반 일정은 시작 1시간 뒤 자동으로 목록에서 숨긴다.
            updateAll(context);
            scheduleNextTodayEventExpiry(context);
            return;
        }
        if (ACTION_REFRESH.equals(action)) {
            final PendingResult result = goAsync();
            WidgetData.refreshExtrasAsync(context, () -> {
                updateAll(context);
                scheduleNextTodayEventExpiry(context);
                result.finish();
            });
            return;
        }
        super.onReceive(context, intent);
    }


    private static void scheduleNextGameDayRollover(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;

        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Seoul"));
        ZonedDateTime next = now.withHour(11).withMinute(0).withSecond(0).withNano(0);
        if (!next.isAfter(now)) next = next.plusDays(1);

        Intent i = new Intent(context, TkorWidgetProvider.class).setAction(ACTION_GAME_DAY_ROLLOVER);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 77111, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        long triggerAt = next.toInstant().toEpochMilli();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms()) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        } else {
            // 정확 알람 권한이 없어도 11시 무렵에는 자동 갱신되도록 예약한다.
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }


    private static void scheduleNextTodayEventExpiry(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;

        Intent i = new Intent(context, TkorWidgetProvider.class).setAction(ACTION_TODAY_EVENT_EXPIRED);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 77112, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        long triggerAt = WidgetData.nextTodayExpiryMillis(context);
        if (triggerAt <= System.currentTimeMillis()) {
            alarm.cancel(pi);
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms()) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        } else {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }

    private static void scheduleShieldEnd(Context context, long endMillis) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarm == null) return;
        Intent i = new Intent(context, TkorWidgetProvider.class).setAction(ACTION_SHIELD_EXPIRED);
        PendingIntent pi = PendingIntent.getBroadcast(context, 77117, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        alarm.set(AlarmManager.RTC_WAKEUP, endMillis, pi);
    }

    private static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, TkorWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    private static boolean isDetail(AppWidgetManager manager, int id) {
        Bundle options = manager.getAppWidgetOptions(id);
        int h = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
        int w = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        if (w > 0 && h > 0) return h >= (int) (w * 1.75f);
        return h >= 600;
    }

    private static boolean isShortCompact(AppWidgetManager manager, int id) {
        Bundle options = manager.getAppWidgetOptions(id);
        int h = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
        return h > 0 && h < 410;
    }

    private static void bindTodayRows(Context context, RemoteViews rv) {
        List<EventItem> events = WidgetData.todayEvents(context);
        for (int i = 0; i < ROW_IDS.length; i++) {
            if (i < events.size()) {
                EventItem e = events.get(i);
                rv.setViewVisibility(ROW_IDS[i], View.VISIBLE);
                rv.setTextViewText(TIME_IDS[i], e.time);
                rv.setTextViewText(NAME_IDS[i], e.name);
                rv.setTextViewText(CHECK_IDS[i], "○");
                PendingIntent pi = actionIntent(context, ACTION_COMPLETE, AppWidgetManager.INVALID_APPWIDGET_ID, e.completionKey(), 20000 + i);
                rv.setOnClickPendingIntent(ROW_IDS[i], pi);
                rv.setOnClickPendingIntent(CHECK_IDS[i], pi);
            } else {
                rv.setViewVisibility(ROW_IDS[i], View.GONE);
            }
        }
    }

    private static void bindSurvival(Context context, RemoteViews rv) {
        List<SurvivalItem> surv = WidgetData.survivalForGameDay();
        for (int i = 0; i < SURV_ROW_IDS.length; i++) {
            SurvivalItem s = surv.get(i);
            rv.setViewVisibility(SURV_ROW_IDS[i], View.VISIBLE);
            rv.setTextViewText(SURV_TIME_IDS[i], s.time);
            rv.setTextViewText(SURV_NAME_IDS[i], s.name);
            rv.setInt(SURV_ROW_IDS[i], "setBackgroundResource", s.highlighted ? R.drawable.bg_row_highlight : R.drawable.bg_row);
            rv.setTextColor(SURV_TIME_IDS[i], context.getColor(s.highlighted ? R.color.gold : R.color.text_main));
        }
    }

    private static void bindGuild(Context context, RemoteViews rv) {
        rv.setTextViewText(R.id.guildDayText, WidgetData.guildDayLabel());
        rv.setTextViewText(R.id.guildNoteText, WidgetData.guildNoteForGameDay());

        boolean saturday = WidgetData.isSaturdayGameDay();
        rv.setViewVisibility(R.id.shieldPanel, saturday ? View.VISIBLE : View.GONE);
        if (saturday) bindShield(context, rv);

        List<GuildTask> tasks = WidgetData.guildTasksForGameDay();
        for (int i = 0; i < GUILD_ROW_IDS.length; i++) {
            if (i < tasks.size()) {
                GuildTask task = tasks.get(i);
                boolean done = WidgetData.isGuildDone(context, task.id);
                rv.setViewVisibility(GUILD_ROW_IDS[i], View.VISIBLE);
                rv.setTextViewText(GUILD_CHECK_IDS[i], done ? "✓" : "○");
                rv.setTextColor(GUILD_CHECK_IDS[i], context.getColor(done ? R.color.gold : R.color.text_muted));
                rv.setTextViewText(GUILD_NAME_IDS[i], task.name);
                PendingIntent pi = actionIntent(context, ACTION_GUILD_TOGGLE, AppWidgetManager.INVALID_APPWIDGET_ID, task.id, 50000 + i);
                rv.setOnClickPendingIntent(GUILD_ROW_IDS[i], pi);
                rv.setOnClickPendingIntent(GUILD_CHECK_IDS[i], pi);
            } else {
                rv.setViewVisibility(GUILD_ROW_IDS[i], View.GONE);
            }
        }
    }

    private static void bindShield(Context context, RemoteViews rv) {
        int hours = WidgetData.shieldHours(context);
        rv.setInt(R.id.shield8, "setBackgroundResource", hours == 8 ? R.drawable.bg_row_highlight : R.drawable.bg_reset);
        rv.setInt(R.id.shield12, "setBackgroundResource", hours == 12 ? R.drawable.bg_row_highlight : R.drawable.bg_reset);
        rv.setTextColor(R.id.shield8, context.getColor(hours == 8 ? R.color.gold : R.color.text_main));
        rv.setTextColor(R.id.shield12, context.getColor(hours == 12 ? R.color.gold : R.color.text_main));
        rv.setOnClickPendingIntent(R.id.shield8, actionIntent(context, ACTION_SHIELD_8, AppWidgetManager.INVALID_APPWIDGET_ID, null, 61008));
        rv.setOnClickPendingIntent(R.id.shield12, actionIntent(context, ACTION_SHIELD_12, AppWidgetManager.INVALID_APPWIDGET_ID, null, 61012));
        rv.setOnClickPendingIntent(R.id.shieldStart, actionIntent(context, ACTION_SHIELD_START, AppWidgetManager.INVALID_APPWIDGET_ID, null, 61100));

        long end = WidgetData.shieldEndMillis(context);
        long remaining = end - System.currentTimeMillis();
        if (remaining > 0) {
            long base = SystemClock.elapsedRealtime() + remaining;
            rv.setViewVisibility(R.id.shieldTimer, View.VISIBLE);
            rv.setChronometer(R.id.shieldTimer, base, null, true);
            rv.setChronometerCountDown(R.id.shieldTimer, true);
            String endText = Instant.ofEpochMilli(end).atZone(ZoneId.of("Asia/Seoul"))
                    .format(DateTimeFormatter.ofPattern("HH:mm"));
            rv.setTextViewText(R.id.shieldStatus, "갱신 " + endText + " · " + hours + "시간");
            rv.setTextViewText(R.id.shieldStart, "다시 시작");
        } else {
            rv.setViewVisibility(R.id.shieldTimer, View.GONE);
            rv.setTextViewText(R.id.shieldStatus, "시간 선택 후 보호막 시작");
            rv.setTextViewText(R.id.shieldStart, "보호막 시작");
        }
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id) {
        boolean detail = isDetail(manager, id);
        boolean shortCompact = !detail && isShortCompact(manager, id);
        int layoutId = detail ? R.layout.widget_detail : (shortCompact ? R.layout.widget_compact_short : R.layout.widget_compact);
        RemoteViews rv = new RemoteViews(context.getPackageName(), layoutId);

        rv.setTextViewText(R.id.dateText, WidgetData.dateLabel());
        rv.setTextViewText(R.id.updatedText, WidgetData.updatedLabel());
        rv.setOnClickPendingIntent(R.id.updatedText, actionIntent(context, ACTION_REFRESH, id, null, 10000 + id));

        bindTodayRows(context, rv);
        bindSurvival(context, rv);

        if (detail) {
            // 세로 상세형은 기존처럼 오늘 일정 + 서바이벌 배틀만 표시한다.
            rv.setTextViewText(R.id.resetText, "초기화");
            rv.setOnClickPendingIntent(R.id.resetText, actionIntent(context, ACTION_RESET, id, null, 9000 + id));
        } else {
            bindGuild(context, rv);
            int page = WidgetData.getCompactPage(context, id);
            if (page < 0 || page > 2) page = 0;
            boolean today = page == 0;
            boolean survival = page == 1;
            boolean guild = page == 2;

            rv.setViewVisibility(R.id.pageToday, today ? View.VISIBLE : View.GONE);
            rv.setViewVisibility(R.id.pageSurvival, survival ? View.VISIBLE : View.GONE);
            rv.setViewVisibility(R.id.pageGuild, guild ? View.VISIBLE : View.GONE);
            rv.setTextViewText(R.id.sectionTitle, today ? "오늘 일정" : (survival ? "서바이벌 배틀" : "길드전"));
            rv.setTextViewText(R.id.dotToday, today ? "●" : "○");
            rv.setTextViewText(R.id.dotSurvival, survival ? "●" : "○");
            rv.setTextViewText(R.id.dotGuild, guild ? "●" : "○");
            rv.setTextColor(R.id.dotToday, context.getColor(today ? R.color.text_main : R.color.text_muted));
            rv.setTextColor(R.id.dotSurvival, context.getColor(survival ? R.color.text_main : R.color.text_muted));
            rv.setTextColor(R.id.dotGuild, context.getColor(guild ? R.color.text_main : R.color.text_muted));

            rv.setOnClickPendingIntent(R.id.dotToday, actionIntent(context, ACTION_SHOW_TODAY, id, null, 30000 + id));
            rv.setOnClickPendingIntent(R.id.dotSurvival, actionIntent(context, ACTION_SHOW_SURVIVAL, id, null, 40000 + id));
            rv.setOnClickPendingIntent(R.id.dotGuild, actionIntent(context, ACTION_SHOW_GUILD, id, null, 45000 + id));

            rv.setTextViewText(R.id.resetText, guild ? "길드 초기화" : "초기화");
            rv.setOnClickPendingIntent(R.id.resetText, actionIntent(context, guild ? ACTION_GUILD_RESET : ACTION_RESET, id, null, 9000 + id));
        }

        manager.updateAppWidget(id, rv);
    }

    private static PendingIntent actionIntent(Context context, String action, int widgetId, String key, int requestCode) {
        Intent i = new Intent(context, TkorWidgetProvider.class);
        i.setAction(action);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        if (key != null) i.putExtra(EXTRA_KEY, key);
        return PendingIntent.getBroadcast(context, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
