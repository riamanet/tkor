package com.tkor.widget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class WidgetData {
    static final ZoneId KST = ZoneId.of("Asia/Seoul");
    private static final String PREF = "tkor_widget";
    private static final String EXTRA_JSON = "extra_json";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final String SHEET_URL =
            "https://docs.google.com/spreadsheets/d/1BOc66VJypBulVOXcXrs6K7GqubbE3rWicXT9ReoAols/gviz/tq" +
            "?sheet=%EA%B3%B5%EA%B0%9C%EB%8D%B0%EC%9D%B4%ED%84%B0&range=C2:E1000&tqx=out:json";

    private WidgetData() {}

    static ZonedDateTime now() {
        return ZonedDateTime.now(KST);
    }

    static String dateLabel() {
        ZonedDateTime now = now();
        String[] day = {"일","월","화","수","목","금","토"};
        int idx = now.getDayOfWeek().getValue() % 7;
        return now.getMonthValue() + "월 " + now.getDayOfMonth() + "일 (" + day[idx] + ")";
    }

    static String updatedLabel() {
        return "최종 갱신 " + now().format(DateTimeFormatter.ofPattern("HH:mm")) + " ↻";
    }

    static String todayKey() {
        // 오늘 일정의 체크/초기화 기준도 게임 하루와 동일하게 11:00 KST로 맞춘다.
        return gameDayDate().toString();
    }

    static List<EventItem> todayEvents(Context context) {
        // 게임 기준 하루: 당일 11:00 ~ 다음날 10:59.
        // 따라서 자정이 지나도 11시 전까지는 같은 "오늘 일정"을 유지한다.
        LocalDate gameDate = gameDayDate();
        LocalDate nextDate = gameDate.plusDays(1);

        List<EventItem> all = new ArrayList<>();
        addEventsInGameWindow(all, baseEvents(gameDate), false);
        addEventsInGameWindow(all, baseEvents(nextDate), true);
        all.addAll(extraEventsForGameDay(context, gameDate));

        // 11:00부터 시작하는 게임 하루 순서로 정렬한다.
        Collections.sort(all, Comparator.comparingInt(e -> gameTimeSortKey(e.time)));

        Set<String> done = doneSet(context);
        List<EventItem> visible = new ArrayList<>();
        for (EventItem e : all) {
            if (!done.contains(e.completionKey())) visible.add(e);
        }
        return visible;
    }

    private static void addEventsInGameWindow(List<EventItem> out, List<EventItem> source, boolean nextCalendarDay) {
        for (EventItem e : source) {
            int minutes = timeToMinutes(e.time);
            if (minutes < 0) continue;
            if ((!nextCalendarDay && minutes >= 11 * 60) || (nextCalendarDay && minutes < 11 * 60)) {
                out.add(e);
            }
        }
    }

    private static int gameTimeSortKey(String time) {
        int minutes = timeToMinutes(time);
        if (minutes < 0) return Integer.MAX_VALUE;
        return minutes < 11 * 60 ? minutes + 24 * 60 : minutes;
    }

    private static int timeToMinutes(String time) {
        try {
            String[] p = time.split(":");
            if (p.length != 2) return -1;
            int h = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            if (h < 0 || h > 23 || m < 0 || m > 59) return -1;
            return h * 60 + m;
        } catch (Exception ignored) {
            return -1;
        }
    }

    private static List<EventItem> baseEvents(LocalDate d) {
        List<EventItem> a = new ArrayList<>();
        LocalDate cheeseStart = LocalDate.of(2026, 9, 20);
        long diff = java.time.temporal.ChronoUnit.DAYS.between(cheeseStart, d);
        if (diff >= 0 && diff % 2 == 0) {
            a.add(new EventItem("19:00", "치즈"));
            a.add(new EventItem("22:00", "치즈"));
        }

        DayOfWeek day = d.getDayOfWeek();
        if (day == DayOfWeek.TUESDAY) a.add(new EventItem("20:30", "좀비포위전"));
        if (day == DayOfWeek.FRIDAY) {
            a.add(new EventItem("20:00", "비약쟁탈전"));
            a.add(new EventItem("20:45", "좀비포위전"));
            a.add(new EventItem("23:00", "왕성쟁탈전"));
        }
        if (day == DayOfWeek.SATURDAY) {
            a.add(new EventItem("10:00", "비약쟁탈전"));
            a.add(new EventItem("23:00", "서버전"));
        }
        if (day == DayOfWeek.SUNDAY) {
            a.add(new EventItem("13:00", "수정골짜기"));
            a.add(new EventItem("20:00", "수정골짜기"));
        }
        if (day == DayOfWeek.MONDAY) {
            a.add(new EventItem("05:00", "수정골짜기"));
            a.add(new EventItem("10:00", "수정골짜기"));
        }
        return a;
    }


    static int getCompactPage(Context context, int widgetId) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getInt("page_" + widgetId, 0);
    }

    static void setCompactPage(Context context, int widgetId, int page) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putInt("page_" + widgetId, page).apply();
    }

    static void clearPageState(Context context, int widgetId) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().remove("page_" + widgetId).apply();
    }

    static Set<String> doneSet(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        return new HashSet<>(sp.getStringSet("done_" + todayKey(), Collections.emptySet()));
    }

    static void markDone(Context context, String key) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Set<String> set = new HashSet<>(sp.getStringSet("done_" + todayKey(), Collections.emptySet()));
        set.add(key);
        sp.edit().putStringSet("done_" + todayKey(), set).apply();
    }

    static void resetToday(Context context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().remove("done_" + todayKey()).apply();
    }

    static List<SurvivalItem> survivalForGameDay() {
        // 게임 기준 하루는 한국시간 11:00에 바뀜.
        DayOfWeek d = now().minusHours(11).getDayOfWeek();
        switch (d) {
            case MONDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","영웅 강화",true},{"15:00 ~ 19:00","영지 건설",false},{"19:00 ~ 23:00","병사 훈련",false},{"23:00 ~ 03:00","기술 연구",false},{"03:00 ~ 07:00","까마귀 강화",true},{"07:00 ~ 11:00","영웅 강화",true}});
            case TUESDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","영지 건설",true},{"15:00 ~ 19:00","병사 훈련",false},{"19:00 ~ 23:00","기술 연구",false},{"23:00 ~ 03:00","까마귀 강화",false},{"03:00 ~ 07:00","영웅 강화",false},{"07:00 ~ 11:00","영지 건설",true}});
            case WEDNESDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","병사 훈련",false},{"15:00 ~ 19:00","기술 연구",true},{"19:00 ~ 23:00","까마귀 강화",false},{"23:00 ~ 03:00","영웅 강화",false},{"03:00 ~ 07:00","영지 건설",false},{"07:00 ~ 11:00","병사 훈련",false}});
            case THURSDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","기술 연구",false},{"15:00 ~ 19:00","까마귀 강화",false},{"19:00 ~ 23:00","영웅 강화",true},{"23:00 ~ 03:00","영지 건설",false},{"03:00 ~ 07:00","병사 훈련",false},{"07:00 ~ 11:00","기술 연구",false}});
            case FRIDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","까마귀 강화",false},{"15:00 ~ 19:00","영웅 강화",false},{"19:00 ~ 23:00","영지 건설",true},{"23:00 ~ 03:00","병사 훈련",true},{"03:00 ~ 07:00","기술 연구",true},{"07:00 ~ 11:00","까마귀 강화",false}});
            case SATURDAY:
                return s(new Object[][]{{"11:00 ~ 15:00","영웅 강화",false},{"15:00 ~ 19:00","영지 건설",true},{"19:00 ~ 23:00","병사 훈련",true},{"23:00 ~ 03:00","기술 연구",true},{"03:00 ~ 07:00","까마귀 강화",false},{"07:00 ~ 11:00","영웅 강화",false}});
            default:
                return s(new Object[][]{{"11:00 ~ 15:00","영지 건설",false},{"15:00 ~ 19:00","병사 훈련",false},{"19:00 ~ 23:00","기술 연구",false},{"23:00 ~ 03:00","까마귀 강화",false},{"03:00 ~ 07:00","영웅 강화",false},{"07:00 ~ 11:00","영지 건설",false}});
        }
    }

    private static List<SurvivalItem> s(Object[][] rows) {
        List<SurvivalItem> out = new ArrayList<>();
        for (Object[] r : rows) out.add(new SurvivalItem((String) r[0], (String) r[1], (Boolean) r[2]));
        return out;
    }


    static LocalDate gameDayDate() {
        return now().minusHours(11).toLocalDate();
    }

    static DayOfWeek gameDay() {
        return gameDayDate().getDayOfWeek();
    }

    static String guildDayLabel() {
        switch (gameDay()) {
            case MONDAY: return "월요일 길드전";
            case TUESDAY: return "화요일 길드전";
            case WEDNESDAY: return "수요일 길드전";
            case THURSDAY: return "목요일 길드전";
            case FRIDAY: return "금요일 길드전";
            case SATURDAY: return "토요일 길드전";
            default: return "일요일 · 길드전 없음";
        }
    }

    static List<GuildTask> guildTasksForGameDay() {
        List<GuildTask> out = new ArrayList<>();
        switch (gameDay()) {
            case MONDAY:
                out.add(new GuildTask("antidote", "항독소 소모 · 영웅 레벨업"));
                out.add(new GuildTask("stamina", "체력 소모"));
                out.add(new GuildTask("falcon", "팔콘타워 완료하기"));
                out.add(new GuildTask("gather", "채집 · 식량/목재/약재"));
                out.add(new GuildTask("raven", "까마귀 레벨업 · 열매/정수"));
                out.add(new GuildTask("rune", "룬 보물상자 오픈"));
                break;
            case TUESDAY:
                out.add(new GuildTask("build", "건설 가속 / 건설 완료"));
                out.add(new GuildTask("urcombo", "UR 비밀퀘스트 · UR 마차 파견"));
                out.add(new GuildTask("recruit", "생존자 모집"));
                break;
            case WEDNESDAY:
                out.add(new GuildTask("falcon", "팔콘타워 완료하기"));
                out.add(new GuildTask("scroll", "연구 두루마리 사용"));
                out.add(new GuildTask("research", "연구 가속 / 연구 완료"));
                out.add(new GuildTask("rune", "까마귀 보물상자 오픈"));
                break;
            case THURSDAY:
                out.add(new GuildTask("antidote", "항독소 사용 · 영웅 레벨업"));
                out.add(new GuildTask("heroRecruit", "영웅 모집"));
                out.add(new GuildTask("heroFrag", "영웅 조각 사용"));
                out.add(new GuildTask("heroStar", "영웅 승급"));
                out.add(new GuildTask("skill", "스킬 배지 사용"));
                break;
            case FRIDAY:
                out.add(new GuildTask("falcon", "팔콘타워 완료하기"));
                out.add(new GuildTask("build", "건설 가속 / 건설 완료"));
                out.add(new GuildTask("train", "병사 훈련 가속 / 병사 훈련"));
                out.add(new GuildTask("research", "연구 가속 / 연구 완료"));
                break;
            case SATURDAY:
                out.add(new GuildTask("kill", "병사 처치 및 전사"));
                out.add(new GuildTask("urcombo", "UR 비밀퀘스트 · UR 마차 파견"));
                out.add(new GuildTask("heal", "치료 가속 사용"));
                out.add(new GuildTask("buildSpeed", "건물 가속 사용 · 완료 X"));
                out.add(new GuildTask("trainSpeed", "병사 가속 사용"));
                out.add(new GuildTask("researchSpeed", "연구 가속 사용"));
                break;
            default:
                break;
        }
        return out;
    }

    static String guildNoteForGameDay() {
        switch (gameDay()) {
            case SUNDAY: return "내일을 위해 팔콘타워를 모아주세요.";
            case TUESDAY:
            case THURSDAY: return "내일을 위해 팔콘타워 임무는 완료 후 모아두기.";
            case SATURDAY: return "보호막을 확인하고 길드전 항목을 진행해주세요.";
            default: return "11:00 KST 기준으로 길드전 항목이 자동 변경됩니다.";
        }
    }

    private static String guildDonePrefKey() {
        return "guild_done_" + gameDayDate();
    }

    static boolean isGuildDone(Context context, String id) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        return sp.getStringSet(guildDonePrefKey(), Collections.emptySet()).contains(id);
    }

    static void toggleGuildDone(Context context, String id) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Set<String> set = new HashSet<>(sp.getStringSet(guildDonePrefKey(), Collections.emptySet()));
        if (!set.add(id)) set.remove(id);
        sp.edit().putStringSet(guildDonePrefKey(), set).apply();
    }

    static void resetGuildToday(Context context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().remove(guildDonePrefKey()).apply();
    }

    static boolean isSaturdayGameDay() {
        return gameDay() == DayOfWeek.SATURDAY;
    }

    static int shieldHours(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getInt("shield_hours", 8);
    }

    static void setShieldHours(Context context, int hours) {
        int safe = hours == 12 ? 12 : 8;
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putInt("shield_hours", safe).apply();
    }

    static long shieldEndMillis(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getLong("shield_end", 0L);
    }

    static long startShield(Context context) {
        long end = System.currentTimeMillis() + shieldHours(context) * 60L * 60L * 1000L;
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putLong("shield_end", end).apply();
        return end;
    }

    static void refreshExtrasAsync(Context context, Runnable done) {
        IO.execute(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(SHEET_URL).openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("User-Agent", "TKORWidget/1.0");
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
                String body = sb.toString();
                int first = body.indexOf('{');
                int last = body.lastIndexOf('}');
                if (first >= 0 && last > first) {
                    JSONObject root = new JSONObject(body.substring(first, last + 1));
                    JSONArray rows = root.optJSONObject("table").optJSONArray("rows");
                    JSONArray store = new JSONArray();
                    if (rows != null) {
                        for (int i = 0; i < rows.length(); i++) {
                            JSONArray c = rows.optJSONObject(i).optJSONArray("c");
                            if (c == null || c.length() < 3) continue;
                            String name = cell(c.optJSONObject(0));
                            String date = normalizeDate(c.optJSONObject(1));
                            String time = normalizeTime(c.optJSONObject(2));
                            if (name.isEmpty() || date.isEmpty() || time.isEmpty()) continue;
                            JSONObject o = new JSONObject();
                            o.put("name", name);
                            o.put("date", date);
                            o.put("time", time);
                            store.put(o);
                        }
                    }
                    context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(EXTRA_JSON, store.toString()).apply();
                }
            } catch (Exception ignored) {
                // 네트워크 실패 시 마지막 캐시를 그대로 사용.
            } finally {
                if (done != null) done.run();
            }
        });
    }

    private static String cell(JSONObject cell) {
        if (cell == null) return "";
        String f = cell.optString("f", "").trim();
        if (!f.isEmpty()) return f;
        Object v = cell.opt("v");
        return v == null ? "" : String.valueOf(v).trim();
    }

    private static String normalizeDate(JSONObject cell) {
        if (cell == null) return "";
        String raw = String.valueOf(cell.opt("v"));
        if (raw.startsWith("Date(")) {
            try {
                String[] p = raw.substring(5, raw.length() - 1).split(",");
                int y = Integer.parseInt(p[0].trim());
                int m = Integer.parseInt(p[1].trim()) + 1;
                int d = Integer.parseInt(p[2].trim());
                return String.format(Locale.US, "%04d-%02d-%02d", y, m, d);
            } catch (Exception ignored) {}
        }
        String s = cell(cell);
        String[] nums = s.replaceAll("[^0-9]+", " ").trim().split("\\s+");
        try {
            if (nums.length >= 3) {
                int a = Integer.parseInt(nums[0]);
                int b = Integer.parseInt(nums[1]);
                int c = Integer.parseInt(nums[2]);
                if (a > 1900) return String.format(Locale.US, "%04d-%02d-%02d", a, b, c);
                if (c > 1900) return String.format(Locale.US, "%04d-%02d-%02d", c, a, b);
            }
        } catch (Exception ignored) {}
        return "";
    }

    private static String normalizeTime(JSONObject cell) {
        String s = cell(cell);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,2}):(\\d{2})").matcher(s);
        if (m.find()) return String.format(Locale.US, "%02d:%02d", Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)));
        return "";
    }

    private static List<EventItem> extraEventsForGameDay(Context context, LocalDate gameDate) {
        String json = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(EXTRA_JSON, "[]");
        List<EventItem> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(json);
            String gameKey = gameDate.toString();
            String nextKey = gameDate.plusDays(1).toString();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                String date = o.optString("date");
                String time = o.optString("time");
                int minutes = timeToMinutes(time);
                if (minutes < 0) continue;

                // 시트 날짜는 실제 달력 날짜 그대로 사용한다.
                // 게임 하루에는 당일 11시 이후 + 다음날 11시 이전 일정이 함께 들어간다.
                boolean sameDay = gameKey.equals(date) && minutes >= 11 * 60;
                boolean nextMorning = nextKey.equals(date) && minutes < 11 * 60;
                if (sameDay || nextMorning) {
                    out.add(new EventItem(time, o.optString("name")));
                }
            }
        } catch (Exception ignored) {}
        return out;
    }
}
