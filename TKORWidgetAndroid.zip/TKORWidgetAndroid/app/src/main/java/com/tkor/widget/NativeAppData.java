package com.tkor.widget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class NativeAppData {
    private static final String PREF = "tkor_native_app";
    private static final String NOTICE_CACHE = "notice_cache";
    private static final String NOTICE_ITEMS_CACHE = "notice_items_cache";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final String BOARD_URL =
            "https://docs.google.com/spreadsheets/d/1BOc66VJypBulVOXcXrs6K7GqubbE3rWicXT9ReoAols/gviz/tq" +
            "?sheet=%EA%B3%B5%EA%B0%9C%EB%8D%B0%EC%9D%B4%ED%84%B0&range=A2:A2&headers=0&tqx=out:json";
    private static final String NOTICE_ITEMS_URL =
            "https://docs.google.com/spreadsheets/d/1BOc66VJypBulVOXcXrs6K7GqubbE3rWicXT9ReoAols/gviz/tq" +
            "?sheet=%EA%B3%B5%EA%B0%9C%EB%8D%B0%EC%9D%B4%ED%84%B0&range=B2:B20&headers=0&tqx=out:json";

    private NativeAppData() {}

    static final class HomeworkItem {
        final String id;
        final String title;
        final String sub;
        HomeworkItem(String id, String title, String sub) {
            this.id = id; this.title = title; this.sub = sub;
        }
    }

    static List<HomeworkItem> homeworkItems() {
        DayOfWeek d = WidgetData.gameDay();
        int day = d.getValue() % 7; // 일0 월1 ... 토6
        boolean falconDoneDay = day == 1 || day == 3 || day == 5;
        boolean urDay = day == 2 || day == 6;
        List<HomeworkItem> out = new ArrayList<>();
        out.add(new HomeworkItem("notice", "공지 확인하기", ""));
        out.add(new HomeworkItem("falcon", falconDoneDay ? "팔콘타워 완료하기" : (day == 6 ? "팔콘타워 완료하기" : "팔콘타워 모으기"), ""));
        out.add(new HomeworkItem("raidWagon", "마차 약탈하기", "약탈 서버는 공지 참고"));
        out.add(new HomeworkItem("dispatch", urDay ? "UR 마차 파견하기" : "마차 파견하기", ""));
        out.add(new HomeworkItem("secretDo", urDay ? "UR 비밀퀘스트 수행" : "비밀퀘스트 수행", ""));
        out.add(new HomeworkItem("secretRaid", "비밀퀘스트 약탈하기", "15:00에 많이 등장"));
        out.add(new HomeworkItem("boss", "마왕보스 잡기", ""));
        return out;
    }

    private static String homeworkKey() {
        return "homework_" + WidgetData.gameDayDate();
    }

    static Set<String> homeworkDone(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        return new HashSet<>(sp.getStringSet(homeworkKey(), Collections.emptySet()));
    }

    static void setHomeworkDone(Context context, String id, boolean checked) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Set<String> set = new HashSet<>(sp.getStringSet(homeworkKey(), Collections.emptySet()));
        if (checked) set.add(id); else set.remove(id);
        sp.edit().putStringSet(homeworkKey(), set).apply();

        DayOfWeek d = WidgetData.gameDay();
        if ("falcon".equals(id) && (d == DayOfWeek.MONDAY || d == DayOfWeek.WEDNESDAY || d == DayOfWeek.FRIDAY)) {
            setGuildState(context, "falcon", checked);
        }
        if (("dispatch".equals(id) || "secretDo".equals(id)) && (d == DayOfWeek.TUESDAY || d == DayOfWeek.SATURDAY)) {
            Set<String> now = homeworkDone(context);
            setGuildState(context, "urcombo", now.contains("dispatch") && now.contains("secretDo"));
        }
        TkorWidgetProvider.requestRefresh(context);
    }

    static void resetHomework(Context context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(homeworkKey()).apply();
    }

    private static void setGuildState(Context context, String id, boolean desired) {
        boolean current = WidgetData.isGuildDone(context, id);
        if (current != desired) WidgetData.toggleGuildDone(context, id);
    }

    static void syncGuildToHomework(Context context, String id) {
        DayOfWeek d = WidgetData.gameDay();
        if ("falcon".equals(id) && (d == DayOfWeek.MONDAY || d == DayOfWeek.WEDNESDAY || d == DayOfWeek.FRIDAY)) {
            setHomeworkDoneOnly(context, "falcon", WidgetData.isGuildDone(context, id));
        }
        if ("urcombo".equals(id) && (d == DayOfWeek.TUESDAY || d == DayOfWeek.SATURDAY)) {
            boolean done = WidgetData.isGuildDone(context, id);
            setHomeworkDoneOnly(context, "dispatch", done);
            setHomeworkDoneOnly(context, "secretDo", done);
        }
    }

    private static void setHomeworkDoneOnly(Context context, String id, boolean checked) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        Set<String> set = new HashSet<>(sp.getStringSet(homeworkKey(), Collections.emptySet()));
        if (checked) set.add(id); else set.remove(id);
        sp.edit().putStringSet(homeworkKey(), set).apply();
    }

    static String cachedNotice(Context context) {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getString(NOTICE_CACHE, "등록된 전광판 소식이 없습니다");
    }

    static List<String> cachedNoticeItems(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw = sp.getString(NOTICE_ITEMS_CACHE, "[]");
        List<String> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String v = arr.optString(i, "").trim();
                if (!v.isEmpty()) out.add(v);
            }
        } catch (Exception ignored) {}
        return out;
    }

    static void refreshNoticeAsync(Context context, NoticeCallback callback) {
        Context app = context.getApplicationContext();
        IO.execute(() -> {
            String value = null;
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(BOARD_URL).openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("User-Agent", "TKORNativeApp/1.0");
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
                String body = sb.toString();
                int first = body.indexOf('{');
                int last = body.lastIndexOf('}');
                if (first >= 0 && last > first) {
                    JSONObject root = new JSONObject(body.substring(first, last + 1));
                    JSONObject table = root.optJSONObject("table");
                    JSONArray rows = table == null ? null : table.optJSONArray("rows");
                    if (rows != null && rows.length() > 0) {
                        JSONArray cells = rows.optJSONObject(0).optJSONArray("c");
                        if (cells != null && cells.length() > 0 && cells.optJSONObject(0) != null) {
                            JSONObject cell = cells.optJSONObject(0);
                            value = cell.optString("f", cell.optString("v", ""));
                        }
                    }
                }
                if (value != null) {
                    value = value.trim();
                    if (value.isEmpty()) value = "등록된 전광판 소식이 없습니다";
                    app.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(NOTICE_CACHE, value).apply();
                }
            } catch (Exception ignored) {}
            final String result = value != null ? value : cachedNotice(app);
            if (callback != null) callback.onNotice(result);
        });
    }

    static void refreshNoticeItemsAsync(Context context, NoticeListCallback callback) {
        Context app = context.getApplicationContext();
        IO.execute(() -> {
            List<String> items = null;
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(NOTICE_ITEMS_URL).openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("User-Agent", "TKORNativeApp/1.0");
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
                String body = sb.toString();
                int first = body.indexOf('{');
                int last = body.lastIndexOf('}');
                if (first >= 0 && last > first) {
                    JSONObject root = new JSONObject(body.substring(first, last + 1));
                    JSONObject table = root.optJSONObject("table");
                    JSONArray rows = table == null ? null : table.optJSONArray("rows");
                    items = new ArrayList<>();
                    if (rows != null) {
                        LinkedHashSet<String> uniq = new LinkedHashSet<>();
                        for (int i = 0; i < rows.length(); i++) {
                            JSONObject row = rows.optJSONObject(i);
                            JSONArray cells = row == null ? null : row.optJSONArray("c");
                            if (cells != null && cells.length() > 0 && cells.optJSONObject(0) != null) {
                                JSONObject cell = cells.optJSONObject(0);
                                String value = cell.optString("f", cell.optString("v", "")).trim();
                                if (!value.isEmpty()) uniq.add(value);
                            }
                        }
                        items.addAll(uniq);
                    }
                    JSONArray cache = new JSONArray();
                    for (String item : items) cache.put(item);
                    app.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(NOTICE_ITEMS_CACHE, cache.toString()).apply();
                }
            } catch (Exception ignored) {}
            final List<String> result = items != null ? items : cachedNoticeItems(app);
            if (callback != null) callback.onLoaded(result);
        });
    }

    interface NoticeCallback { void onNotice(String value); }
    interface NoticeListCallback { void onLoaded(List<String> items); }
}
